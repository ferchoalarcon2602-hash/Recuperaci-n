from django.db import models

# Create your models here.
from django.db import models

# Create your models here.
class aprendiz (models.Model):
    nombre  = models.CharField(max_length = 25)
    apellido = models.CharField(max_length = 25)
    documento = models.IntegerField(unique = True)
    correo = models.EmailField(unique = True)
    telefono = models.IntegerField(unique=True)
    ficha = models.IntegerField()
    tipo_de_documento = models.CharField(max_length = 25)





    def __str__ (self):
        return f'{self.nombre.apellido.documento.correo.telefono.ficha.tipo_de_documento}'